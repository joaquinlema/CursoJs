Curso: desarrollador frontend
Clase: 1
Version: 1.0
-
Temas a ejercitar
  selección de elementos DOM con querySelector()
  manipulación DOM
-
Autor: sergio.minutoli@educacionit.com